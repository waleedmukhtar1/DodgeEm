//============================================================================
// Name        : game.cpp
// Author      : Hassan Mustafa
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Dodge 'Em...
//============================================================================

#ifndef DODGE_CPP_
#define DODGE_CPP_
#include "util.h"
#include <iostream>
#include<string>
#include<cmath> // for basic math functions such as cos, sin, sqrt
using namespace std;

int positionx=0;
int positiony=0;
int position_y=0;
int position_x=0;
int x_1;
int y_1;
float x2 = 40;
float y2 = 35;
// seed the random numbers generator by current time (see the documentation of srand for further help)...

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}


/*
 * Main Canvas drawing function.
 * */
//Board *b;
void GameDisplay()/**/{

int arr[840][900];
	// set the background color using function glClearColor.
	// to change the background play with the red, green and blue values below.
	// Note that r, g and b values must be in the range [0,1] where 0 means dim rid and 1 means pure red and so on.

	glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
			0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors

	// calling some functions from util.cpp file to help students

	//Square at 400,20 position
	//DrawSquare( 400 , 20 ,40,colors[RED]); 
	//Square at 250,250 position
	//DrawSquare( 250 , 250 ,20,colors[GREEN]); 
	//Display Score
	//DrawString( 50, 800, "Score=0", colors[MISTY_ROSE]);
	//Triangle at 300, 450 position
	//DrawTriangle( 300, 450 , 340, 450 , 320 , 490, colors[MISTY_ROSE] ); 
	// Trianlge Vertices v1(300,50) , v2(500,50) , v3(400,250)
	//Circle at 50, 670 position
	//DrawCircle(50,670,10,colors[RED]);
	//Line from 550,50 to 550,480 with width 10
	//DrawLine(int x1, int y1, int x2, int y2, int lwidth, float *color)
	//DrawLine( 550 , 50 ,  550 , 480 , 10 , colors[MISTY_ROSE] );	
	
	// Drawing opponent car

	 
	
	float width = 10; 
	float height = 5;
	float* color = colors[VIOLET]; 
	float radius = 5.0;
	DrawRoundRect(x2,y2,width,height,color,radius); // bottom left tyre
	DrawRoundRect(x2+width*3,y2,width,height,color,radius); // bottom right tyre
	DrawRoundRect(x2+width*3,y2+height*4,width,height,color,radius); // top right tyre
	DrawRoundRect(x2,y2+height*4,width,height,color,radius); // top left tyre
	DrawRoundRect(x2, y2+height*2, width, height, color, radius/2); // body left rect
	DrawRoundRect(x2+width, y2+height, width*2, height*3, color, radius/2); // body center rect
	DrawRoundRect(x2+width*3, y2+height*2, width, height, color, radius/2); // body right rect
	
	
	
	//User's Car
	 x_1 = 405+positionx;
	 y_1 = 35+positiony; 
	 
	
	float* color_1 = colors[RED]; 
	
	DrawRoundRect(x_1,y_1,width,height,color_1,radius); // bottom left tyre
	DrawRoundRect(x_1+width*3,y_1,width,height,color_1,radius); // bottom right tyre
	DrawRoundRect(x_1+width*3,y_1+height*4,width,height,color_1,radius); // top right tyre
	DrawRoundRect(x_1,y_1+height*4,width,height,color_1,radius); // top left tyre
	DrawRoundRect(x_1, y_1+height*2, width, height, color_1, radius/2); // body left rect
	DrawRoundRect(x_1+width, y_1+height, width*2, height*3, color_1, radius/2); // body center rect
	DrawRoundRect(x_1+width*3, y_1+height*2, width, height, color_1, radius/2); // body right rect

	DrawString( 50, 850, "Score=0", colors[MISTY_ROSE]);

	// Drawing Arena
	int gap_turn = 60;
	int sx = 20;
	int sy = 10;
	int swidth = 810/2 - gap_turn/2; // half width
	int sheight = 10;
	float *scolor = colors[RED];
	DrawRectangle(sx, sy, swidth, sheight, scolor); // bottom left
	DrawRectangle(sx + swidth + gap_turn, sy, swidth, sheight, scolor); // bottom right
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight, sheight*2, swidth, scolor); // right down
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight+swidth+gap_turn, sheight*2, swidth, scolor); // right up
	DrawRectangle(sx + swidth + gap_turn, sy+810, swidth, sheight, scolor); // top left
	DrawRectangle(sx, sy+810, swidth, sheight, scolor); // top right
	DrawRectangle(sx-sheight*2, sy+sheight+swidth+gap_turn, sheight*2, swidth, scolor); // left up
	DrawRectangle(sx-sheight*2, sy+sheight, sheight*2, swidth, scolor); // left down

	 gap_turn = 60;
	 sx =117;
	 sy = 110;
	 swidth = 610/2 - gap_turn/2; // half width
	 sheight = 10;
	float *scolor1 = colors[WHITE];
	DrawRectangle(sx, sy, swidth, sheight, scolor1); // bottom left
	DrawRectangle(sx + swidth + gap_turn, sy, swidth, sheight, scolor1); // bottom right
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight, sheight*2, swidth, scolor1); // right down
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight+swidth+gap_turn, sheight*2, swidth, scolor1); // right up
	DrawRectangle(sx + swidth + gap_turn, sy+610, swidth, sheight, scolor1); // top left
	DrawRectangle(sx, sy+610, swidth, sheight, scolor1); // top right
	DrawRectangle(sx-sheight*2, sy+sheight+swidth+gap_turn, sheight*2, swidth, scolor1); // left up
	DrawRectangle(sx-sheight*2, sy+sheight, sheight*2, swidth, scolor1); // left down

	 gap_turn = 60;
	 sx =217;
	 sy = 210;
	 swidth = 410/2 - gap_turn/2; // half width
	 sheight = 10;
	float *scolor2 = colors[WHITE];
	DrawRectangle(sx, sy, swidth, sheight, scolor2); // bottom left
	DrawRectangle(sx + swidth + gap_turn, sy, swidth, sheight, scolor2); // bottom right
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight, sheight*2, swidth, scolor2); // right down
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight+swidth+gap_turn, sheight*2, swidth, scolor2); // right up
	DrawRectangle(sx + swidth + gap_turn, sy+410, swidth, sheight, scolor2); // top left
	DrawRectangle(sx, sy+410, swidth, sheight, scolor2); // top right
	DrawRectangle(sx-sheight*2, sy+sheight+swidth+gap_turn, sheight*2, swidth, scolor2); // left up
	DrawRectangle(sx-sheight*2, sy+sheight, sheight*2, swidth, scolor2); // left down

	 gap_turn = 60;
	 sx =317;
	 sy = 310;
	 swidth = 210/2 - gap_turn/2; // half width
	 sheight = 10;
	float *scolor3 = colors[WHITE];
	DrawRectangle(sx, sy, swidth, sheight, scolor3); // bottom left
	DrawRectangle(sx + swidth + gap_turn, sy, swidth, sheight, scolor3); // bottom right
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight, sheight*2, swidth, scolor3); // right down
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight+swidth+gap_turn, sheight*2, swidth, scolor3); // right up
	DrawRectangle(sx + swidth + gap_turn, sy+210, swidth, sheight, scolor3); // top left
	DrawRectangle(sx, sy+210, swidth, sheight, scolor3); // top right
	DrawRectangle(sx-sheight*2, sy+sheight+swidth+gap_turn, sheight*2, swidth, scolor3); // left up
	DrawRectangle(sx-sheight*2, sy+sheight, sheight*2, swidth, scolor3); // left down

	 gap_turn = 0;
	 sx =400;
	 sy = 390;
	 swidth = 50/2 - gap_turn/4; // half width
	 sheight = 10;
	float *scolor4 = colors[WHITE];
	DrawRectangle(sx, sy, swidth, sheight, scolor4); // bottom left
	DrawRectangle(sx + swidth + gap_turn, sy, swidth, sheight, scolor4); // bottom right
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight, sheight*2, swidth, scolor4); // right down
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight+swidth+gap_turn, sheight*2, swidth, scolor4); // right up
	DrawRectangle(sx + swidth + gap_turn, sy+50, swidth, sheight, scolor4); // top left
	DrawRectangle(sx, sy+50, swidth, sheight, scolor4); // top right
	DrawRectangle(sx-sheight*2, sy+sheight+swidth+gap_turn, sheight*2, swidth, scolor4); // left up
	DrawRectangle(sx-sheight*2, sy+sheight, sheight*2, swidth, scolor4); // left down



	
       for(int i=50;i<850;i+=105)
	{

		for(int j=50;j<850;j+=100)
		{
			
			if((i>x_1&& i<x_1+50)  && (j>y_1&& j<y_1+50)   )
		
		{ arr[i][j]=100;}
			
		}


	}
       for(int i=50;i<850;i+=105)
	{

		for(int j=50;j<850;j+=100)
		{
		if(arr[i][j]==100)
{
		
		}

		else
			
		
		DrawCircle(i,j,10,colors[WHITE]);
		}



		}





	glutSwapBuffers(); // do not modify this line.. or draw anything below this line
}

/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */

void NonPrintableKeys(int key, int x, int y) {
	if (key
			== GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/) {
		// what to do when left key is pressed...
	positionx=positionx-8;
cout<<"x is  = "<<x_1<<" y  = "<<y_1<<endl;
	glutDisplayFunc(GameDisplay);
	

	} else if (key
			== GLUT_KEY_RIGHT /*GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/) {
	positionx=positionx+10;
cout<<"x is  = "<<x_1<<" y  = "<<y_1<<endl;
	glutDisplayFunc(GameDisplay);

	} else if (key
			== GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) {
	positiony=positiony+10;
cout<<"x is  = "<<x_1<<" y  = "<<y_1<<endl;
	glutDisplayFunc(GameDisplay);

	}

	else if (key
			== GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) {
	positiony=positiony-10;
cout<<"x is  = "<<x_1<<" y  = "<<y_1<<endl;
	glutDisplayFunc(GameDisplay);

	}

	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();

}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y) {
	if (key == 27/* Escape key ASCII*/) {
		exit(1); // exit the program when escape key is pressed.
	}

	if (key == 'b' || key == 'B')
			{
		//do something if b is pressed
		cout << "b pressed" << endl;

	}
	glutPostRedisplay();
}

/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
void Timer(int m) {
	
	
	if((x2>=18 && x2<=755   ) && (y2>=35 && y2<=65  ))
	{
	x2+=10;
x_1-=10;
	glutPostRedisplay();
	}
else
if((x2>=755 && x2<=789   ) &&  (y2>=35 && y2<=740  ))

	{
	y2+=10;
y_1-=10;
	glutPostRedisplay();
	}
else
if((x2>=49 && x2<=781   ) && (y2>=740 && y2<=755  ))
	{

	x2-=10;
x_1+=10;
	glutPostRedisplay();
	}
else
if((x2>=30 && x2<=49   ) && (y2>=0 && y2<=750  ))
	{

	y2-=10;
y_1-=10;
	glutPostRedisplay();
	}


	
	
	
	
	



	// implement your functionality here

	// once again we tell the library to call our Timer function after next 1000/FPS
	glutTimerFunc(70.0, Timer, 0);
}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y) {
	cout << x << " " << y << endl;
	glutPostRedisplay();
}
void MouseMoved(int x, int y) {

	glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y) {

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
			{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;

	} else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
			{

	}
	glutPostRedisplay();
}
/*
 * our gateway main function
 * */
int main(int argc, char*argv[]) {

	//b = new Board(60, 60); // create a new board object to use in the Display Function ...

	int width = 840, height = 900; // i have set my window size to be 800 x 600
	//b->InitalizeBoard(width, height);
	InitRandomizer(); // seed the random number generator...
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("OOP Centipede"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...

	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved); // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif /* AsteroidS_CPP_ */
